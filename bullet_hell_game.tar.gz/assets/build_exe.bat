@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconsole --onefile --name BulletHell --add-data "assets;assets" main.py
echo 完成：dist\BulletHell.exe（可直接複製到沒有安裝 Python 的電腦執行）
pause
