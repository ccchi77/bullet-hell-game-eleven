import asyncio #github
import json
import math
import os
import random
import sys

import pygame

from game_rules import GameRules
# 基本設定
W, H = 1280, 677                         # 遊戲邏輯解析度（視窗可縮放，會自動等比放大）
FPS = 60
TITLE = "彈幕遊戲"
DEBUG_KEYS = False                   # True：遊戲中 F1~F4 手動生怪（測試用）。接上定時生怪後可改 False

# 可飛行區域（背景圖中間的「艙窗」，不含左側/下方的機械框）。玩家、敵機、子彈都只會在這裡顯示
PLAY = pygame.Rect(205, 50, 1030, 430)

PLAYER_MAX_HP = 5
PLAYER_SPEED = 340                       # 像素/秒
PLAYER_SLOW_SPEED = 150                  # 按住 Shift
PLAYER_HIT_R = 9                         # 玩家判定點半徑（比外觀小很多，這是彈幕遊戲慣例）
PLAYER_FIRE_INTERVAL = 0.11
PLAYER_INVULN_TIME = 2.0                 # 受傷後無敵秒數

# 敵機種類表：score 只是「建議分數」，給 GameRules 計分時參考用
ENEMY_KINDS = {
    "aimed": dict(hp=8,  speed=140, amp=70, freq=1.6, interval=1.3,  pattern="aimed",
                  score=100, scale=0.9,  hit_r=30),
    "fan":   dict(hp=14, speed=95,  amp=40, freq=1.1, interval=1.9,  pattern="fan",
                  score=200, scale=1.0,  hit_r=34),
    "ring":  dict(hp=24, speed=100, amp=0,  freq=0.0, interval=2.3,  pattern="ring",
                  score=400, scale=1.25, hit_r=44, hover_x=PLAY.right - 220, stay=9.0),
    "spiral": dict(hp=34, speed=100, amp=25, freq=0.8, interval=0.11, pattern="spiral",
                   score=600, scale=1.3, hit_r=46, hover_x=PLAY.right - 170, stay=10.0),
}

# 主選單圖片（menu.jpg）上四顆按鈕的位置（1280x677 座標）
MENU_RECTS = [
    pygame.Rect(469, 170, 342, 62),      # 開始遊戲
    pygame.Rect(469, 249, 342, 62),      # 操作說明
    pygame.Rect(469, 328, 342, 61),      # 設定
    pygame.Rect(469, 406, 342, 63),      # 離開遊戲
]

# 顏色
CYAN = (120, 225, 255)
PURPLE = (205, 140, 235)
WHITE = (240, 248, 255)
GREY = (150, 165, 190)
RED = (255, 90, 90)



# 工具：路徑、存檔、字型、文字

def base_path():
    #程式/素材所在資料夾。打包成 exe (PyInstaller) 後會指向暫存解壓目錄
    return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))


def asset(*parts):
    return os.path.join(base_path(), "assets", *parts)


def user_data_dir():
    #可寫入的存檔資料夾（設定檔、排行榜）。
    
    home = os.path.join(os.path.expanduser("~"), ".bullet_hell_game")
    if getattr(sys, "frozen", False):
        root = home
    else:
        root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "save_data")
    try:
        os.makedirs(root, exist_ok=True)
        if not os.access(root, os.W_OK):
            raise OSError
    except OSError:
        root = home
        os.makedirs(root, exist_ok=True)
    return root


class Settings:
    #設定檔 settings.json：音樂 / 音效音量 (0.0~1.0)
    DEFAULTS = {"music_volume": 0.6, "sfx_volume": 0.8}

    def __init__(self, data_dir):
        self.path = os.path.join(data_dir, "settings.json")
        self.data = dict(self.DEFAULTS)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            for k in self.DEFAULTS:
                if isinstance(loaded.get(k), (int, float)):
                    self.data[k] = max(0.0, min(1.0, float(loaded[k])))
        except (OSError, ValueError, AttributeError):
            pass

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = max(0.0, min(1.0, float(value)))

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
        except OSError:
            pass


class Fonts:
    #中文字型：優先使用內附的 Noto Sans TC（assets/fonts），所以換電腦也不會變成方塊字
    path = asset("fonts", "NotoSansTC-Bold-subset.otf")
    _cache = {}

    @classmethod
    def get(cls, size):
        font = cls._cache.get(size)
        if font is None:
            try:
                font = pygame.font.Font(cls.path, size)
            except (OSError, pygame.error):
                font = pygame.font.SysFont(
                    "microsoftjhenghei,pingfangtc,notosanscjktc,notosanscjk,arialunicodems", size)
            cls._cache[size] = font
        return font


def draw_text(surf, text, size, color, pos, anchor="center", shadow=True):
    font = Fonts.get(size)
    img = font.render(text, True, color)
    rect = img.get_rect(**{anchor: pos})
    if shadow:
        surf.blit(font.render(text, True, (0, 0, 0)), rect.move(2, 2))
    surf.blit(img, rect)
    return rect


def make_orb(radius, core, glow):
    """發光圓形彈（敵方子彈）。"""
    size = radius * 4
    c = size // 2
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    for r in range(radius * 2, radius, -1):
        t = (r - radius) / radius
        pygame.draw.circle(s, (*glow, int(170 * (1 - t) ** 2)), (c, c), r)
    pygame.draw.circle(s, (*glow, 255), (c, c), radius)
    pygame.draw.circle(s, (*core, 255), (c, c), max(1, int(radius * 0.55)))
    return s


def make_bolt():
    """玩家子彈（青色光束）。"""
    s = pygame.Surface((44, 16), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (60, 180, 255, 90), (0, 0, 44, 16))
    pygame.draw.ellipse(s, (110, 220, 255, 200), (4, 3, 36, 10))
    pygame.draw.ellipse(s, (255, 255, 255, 255), (9, 5, 26, 6))
    return s


#  素材與音效
class Assets:
    def __init__(self):
        img = lambda n: pygame.image.load(asset("images", n))
        self.menu_bg = img("menu.jpg").convert()
        self.game_bg = img("background.jpg").convert()

        p = img("player.png").convert_alpha()
        pw = 112
        self.player_img = pygame.transform.smoothscale(p, (pw, round(p.get_height() * pw / p.get_width())))

        self._enemy_src = img("enemy.png").convert_alpha()
        self._enemy_cache = {}

        # 子彈外觀：name -> (surface, 判定半徑)
        self.orbs = {
            "red": (make_orb(7, (255, 230, 230), (255, 50, 60)), 6),
            "orange": (make_orb(6, (255, 250, 220), (255, 150, 40)), 5),
            "purple": (make_orb(9, (255, 235, 255), (190, 80, 255)), 8),
        }
        self.bolt = make_bolt()

    def enemy_sprites(self, scale):
        """依縮放取得 (一般圖, 受擊閃白圖)，有快取。"""
        if scale not in self._enemy_cache:
            w = int(100 * scale)
            src = self._enemy_src
            normal = pygame.transform.smoothscale(src, (w, round(src.get_height() * w / src.get_width())))
            flash = normal.copy()
            flash.fill((110, 110, 110, 0), special_flags=pygame.BLEND_RGB_ADD)
            self._enemy_cache[scale] = (normal, flash)
        return self._enemy_cache[scale]


class Audio:
    """音效 / 音樂。沒有音效裝置時會安靜略過，不會讓遊戲當掉。"""
    NAMES = ("shoot", "explode", "hit", "click", "select")

    def __init__(self, settings):
        self.settings = settings
        self.ok = pygame.mixer.get_init() is not None
        if not self.ok:
            try:
                pygame.mixer.init()
                self.ok = True
            except pygame.error:
                self.ok = False
        self.sounds = {}
        if self.ok:
            for n in self.NAMES:
                path = asset("audio", n + ".wav")
                if os.path.exists(path):
                    try:
                        self.sounds[n] = pygame.mixer.Sound(path)
                    except pygame.error:
                        pass

    def play(self, name, scale=1.0):
        snd = self.sounds.get(name)
        if snd:
            snd.set_volume(min(1.0, self.settings["sfx_volume"] * scale))
            snd.play()

    def play_music(self):
        path = asset("audio", "bgm.wav")
        if self.ok and os.path.exists(path):
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(self.settings["music_volume"])
                pygame.mixer.music.play(-1)
            except pygame.error:
                pass

    def apply_volumes(self):
        if self.ok:
            pygame.mixer.music.set_volume(self.settings["music_volume"])


#遊戲物件：子彈、玩家、敵機、粒子
class Bullet:
    __slots__ = ("x", "y", "vx", "vy", "r", "img", "hw", "hh", "dmg", "dead")

    def __init__(self, x, y, vx, vy, r, img, dmg=1):
        self.x, self.y, self.vx, self.vy, self.r, self.img, self.dmg = x, y, vx, vy, r, img, dmg
        self.hw, self.hh = img.get_width() / 2, img.get_height() / 2
        self.dead = False

    def update(self, dt, bounds):
        self.x += self.vx * dt
        self.y += self.vy * dt
        if not bounds.collidepoint(self.x, self.y):
            self.dead = True

    def draw(self, surf):
        surf.blit(self.img, (self.x - self.hw, self.y - self.hh))


class Player:
    def __init__(self, img):
        self.img = img
        self.w, self.h = img.get_size()
        self.max_hp = PLAYER_MAX_HP
        self.hit_r = PLAYER_HIT_R
        self.reset()

    def reset(self):
        self.x, self.y = PLAY.left + 110, PLAY.centery
        self.hp = self.max_hp
        self.alive = True
        self.invuln = 0.0
        self.fire_cd = 0.0
        self.slow = False

    def update(self, dt, keys):
        dx = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
        dy = (keys[pygame.K_DOWN] or keys[pygame.K_s]) - (keys[pygame.K_UP] or keys[pygame.K_w])
        self.slow = bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
        if dx and dy:
            dx *= 0.7071
            dy *= 0.7071
        speed = PLAYER_SLOW_SPEED if self.slow else PLAYER_SPEED
        self.x += dx * speed * dt
        self.y += dy * speed * dt
        area = PLAY.inflate(-70, -50)
        self.x = max(area.left, min(area.right, self.x))
        self.y = max(area.top, min(area.bottom, self.y))
        self.invuln = max(0.0, self.invuln - dt)
        self.fire_cd = max(0.0, self.fire_cd - dt)

    def draw(self, surf, t):
        if self.invuln > 0 and int(t * 12) % 2 == 0:      # 無敵時閃爍
            return
        surf.blit(self.img, (self.x - self.w / 2, self.y - self.h / 2))
        if self.slow:                                       # 低速時顯示判定點
            pygame.draw.circle(surf, (255, 80, 80), (int(self.x), int(self.y)), self.hit_r + 3, 2)
            pygame.draw.circle(surf, (255, 255, 255), (int(self.x), int(self.y)), self.hit_r - 3)


class Enemy:
    """敵機。外觀共用 enemy.png，行為由 ENEMY_KINDS 表決定。"""

    def __init__(self, kind, x, y, assets):
        cfg = ENEMY_KINDS[kind]
        self.kind = kind
        self.x, self.y, self.base_y = x, y, y
        self.hp = self.max_hp = cfg["hp"]
        self.speed, self.amp, self.freq = cfg["speed"], cfg["amp"], cfg["freq"]
        self.interval, self.pattern = cfg["interval"], cfg["pattern"]
        self.score_value = cfg["score"]
        self.hit_r = cfg["hit_r"]
        self.hover_x = cfg.get("hover_x")
        self.stay = cfg.get("stay", 0.0)
        self.img, self.flash_img = assets.enemy_sprites(cfg["scale"])
        self.w, self.h = self.img.get_size()
        self.t = 0.0
        self.hover_t = 0.0
        self.leaving = False
        self.cd = random.uniform(0.5, 1.2)
        self.flash = 0.0
        self.spiral_angle = random.uniform(0, math.tau)
        self.dead = False

    def hurt(self, dmg):
        self.hp -= dmg
        self.flash = 0.07

    def update(self, dt, scene):
        self.t += dt
        self.flash = max(0.0, self.flash - dt)
        if self.hover_x is not None and not self.leaving:
            if self.x > self.hover_x:
                self.x -= self.speed * dt
            else:
                self.hover_t += dt
                if self.hover_t >= self.stay:
                    self.leaving = True
        else:
            self.x -= (170 if self.leaving else self.speed) * dt
        self.y = self.base_y + self.amp * math.sin(self.t * self.freq)

        # 只有進入可玩區域才開火
        if PLAY.left + 20 < self.x < PLAY.right - 10 and scene.player.alive:
            self.cd -= dt
            if self.cd <= 0:
                self.cd += self.interval
                self.fire(scene)
        if self.x < PLAY.left - 120:                       # 飛出左邊 = 不算擊殺、無分數
            self.dead = True

    def fire(self, scene):
        """【FR：敵方彈幕生成】四種彈幕型態。想新增型態就在 ENEMY_KINDS 加一筆並在這裡加一個 elif。"""
        mx = self.x - self.w * 0.4                         # 砲口在機頭（左側）
        aim = math.atan2(scene.player.y - self.y, scene.player.x - mx)
        if self.pattern == "aimed":
            scene.enemy_shot(mx, self.y, aim, 270, "red")
        elif self.pattern == "fan":
            for i in range(-2, 3):
                scene.enemy_shot(mx, self.y, aim + i * 0.22, 240, "orange")
        elif self.pattern == "ring":
            off = random.uniform(0, math.tau)
            for i in range(18):
                scene.enemy_shot(self.x, self.y, off + i * math.tau / 18, 170, "purple")
        elif self.pattern == "spiral":
            for k in range(2):
                scene.enemy_shot(self.x, self.y, self.spiral_angle + k * math.pi, 200, "red")
            self.spiral_angle += 0.38

    def draw(self, surf):
        img = self.flash_img if self.flash > 0 else self.img
        surf.blit(img, (self.x - self.w / 2, self.y - self.h / 2))
        if self.hp < self.max_hp:                          # 受傷後顯示小血條
            bw = self.w * 0.6
            x0, y0 = self.x - bw / 2, self.y - self.h / 2 - 8
            pygame.draw.rect(surf, (40, 10, 20), (x0, y0, bw, 5))
            pygame.draw.rect(surf, (255, 80, 90), (x0, y0, bw * max(0, self.hp) / self.max_hp, 5))


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size")

    def __init__(self, x, y, vx, vy, life, color, size):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max_life = life
        self.color, self.size = color, size


#場景系統
class Scene:
    def __init__(self, game):
        self.game = game

    def handle_event(self, e):
        pass

    def update(self, dt):
        pass

    def draw(self, surf):
        pass


class ButtonList:
    """可用滑鼠（懸停/點擊）與鍵盤（↑↓ + Enter）操作的按鈕清單。
    style="solid"：自己畫按鈕；style="glow"：只在既有圖片按鈕上疊發光框（主選單用）。"""

    def __init__(self, game, items, rects=None, style="solid", top=0, cx=W // 2,
                 w=380, h=60, gap=18, font=30):
        self.game, self.items, self.style, self.font = game, items, style, font
        self.index = 0
        if rects is None:
            rects = [pygame.Rect(cx - w // 2, top + i * (h + gap), w, h) for i in range(len(items))]
        self.rects = rects

    def _set(self, i):
        if i != self.index:
            self.index = i
            self.game.audio.play("select")

    def handle_event(self, e):
        if e.type == pygame.MOUSEMOTION:
            for i, r in enumerate(self.rects):
                if r.collidepoint(e.pos):
                    self._set(i)
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, r in enumerate(self.rects):
                if r.collidepoint(e.pos):
                    self.index = i
                    self._fire()
                    return
        elif e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_UP, pygame.K_w):
                self._set((self.index - 1) % len(self.items))
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self._set((self.index + 1) % len(self.items))
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self._fire()

    def _fire(self):
        self.game.audio.play("click")
        self.items[self.index][1]()

    def draw(self, surf):
        for i, (label, _) in enumerate(self.items):
            r = self.rects[i]
            sel = i == self.index
            box = pygame.Surface(r.size, pygame.SRCALPHA)
            if self.style == "solid":
                pygame.draw.rect(box, (18, 26, 52, 225), box.get_rect(), border_radius=12)
                pygame.draw.rect(box, (*(CYAN if sel else PURPLE), 255 if sel else 150),
                                 box.get_rect(), 3 if sel else 2, border_radius=12)
            elif sel:
                pygame.draw.rect(box, (120, 225, 255, 45), box.get_rect(), border_radius=10)
                pygame.draw.rect(box, (160, 240, 255, 235), box.get_rect(), 3, border_radius=10)
            surf.blit(box, r.topleft)
            if self.style == "solid":
                draw_text(surf, label, self.font, WHITE if sel else GREY, r.center)


def dimmed_background(surf, assets, alpha=150):
    surf.blit(assets.game_bg, (0, 0))
    veil = pygame.Surface((W, H), pygame.SRCALPHA)
    veil.fill((6, 8, 20, alpha))
    surf.blit(veil, (0, 0))


def draw_panel(surf, rect):
    p = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(p, (14, 20, 44, 215), p.get_rect(), border_radius=16)
    pygame.draw.rect(p, (*CYAN, 200), p.get_rect(), 3, border_radius=16)
    surf.blit(p, rect.topleft)


#  主選單
class MainMenuScene(Scene):
    def __init__(self, game):
        super().__init__(game)
        items = [("開始遊戲", self.start), ("操作說明", self.help),
                 ("設定", self.settings), ("離開遊戲", self.quit)]
        self.buttons = ButtonList(game, items, rects=MENU_RECTS, style="glow")

    def start(self):
        self.game.push(DifficultyScene(self.game))#選擇難度

    def help(self):
        self.game.push(HelpScene(self.game))

    def settings(self):
        self.game.push(SettingsScene(self.game))

    def quit(self):
        self.game.running = False

    def handle_event(self, e):
        self.buttons.handle_event(e)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.quit()

    def draw(self, surf):
        surf.blit(self.game.assets.menu_bg, (0, 0))
        self.buttons.draw(surf)

#各難度產出的敵機(4種難度都是各4關，然後前三個難度都是一樣的規則，第四關稍有不同)
class DifficultyScene(Scene):
    def __init__(self, game):
        super().__init__(game)
        items = [
            ("難度 1", lambda: self.select(1)),
            ("難度 2", lambda: self.select(2)),
            ("難度 3", lambda: self.select(3)),
            ("難度 4", lambda: self.select(4)),
            ("返回主選單", self.back),
        ]
        self.buttons = ButtonList(game, items, top=185, w=420, h=56, gap=14, font=28)

    def select(self, diff):
        self.game.replace(GameplayScene(self.game, difficulty=diff))

    def back(self):
        self.game.pop()

    def handle_event(self, e):
        self.buttons.handle_event(e)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.back()

    def draw(self, surf):
        dimmed_background(surf, self.game.assets)
        draw_panel(surf, pygame.Rect(340, 60, 600, 540))
        draw_text(surf, "選擇難度", 46, CYAN, (W // 2, 118))
        self.buttons.draw(surf)

#  操作說明
class HelpScene(Scene):
    ROWS = [("移動", "W A S D / 方向鍵"),
            ("射擊", "Z / J / 空白鍵（按住連射）"),
            ("精準移動", "按住 Shift：減速並顯示判定點"),
            ("暫停", "ESC / P"),
            ("全螢幕", "F11")]

    def __init__(self, game):
        super().__init__(game)
        self.buttons = ButtonList(game, [("返回", self.back)], top=565, w=240, h=54, font=28)

    def back(self):
        self.game.pop()

    def handle_event(self, e):
        self.buttons.handle_event(e)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.back()

    def draw(self, surf):
        a = self.game.assets
        dimmed_background(surf, a)
        panel = pygame.Rect(260, 60, 760, 480)
        draw_panel(surf, panel)
        draw_text(surf, "操作說明", 46, CYAN, (W // 2, 105))
        y = 170
        for k, v in self.ROWS:
            draw_text(surf, k, 28, PURPLE, (310, y), "midleft")
            draw_text(surf, v, 28, WHITE, (470, y), "midleft")
            y += 50
        pimg = pygame.transform.smoothscale(a.player_img, (80, round(a.player_img.get_height() * 80 / a.player_img.get_width())))
        eimg = a.enemy_sprites(0.8)[0]
        surf.blit(pimg, (300, 430))
        draw_text(surf, "我方（藍）", 24, CYAN, (395, 455), "midleft")
        surf.blit(eimg, (600, 425))
        draw_text(surf, "敵方（黑紅）", 24, RED, (690, 455), "midleft")
        draw_text(surf, "擊破敵機、閃避彈幕，生存越久越好！", 24, GREY, (W // 2, 510))
        self.buttons.draw(surf)


#  設定（音效 / 音樂調整）
class SettingsScene(Scene):
    SLIDERS = [("音樂音量", "music_volume"), ("音效音量", "sfx_volume")]

    def __init__(self, game):
        super().__init__(game)
        self.index = 0
        self.drag = None
        self.tracks = [pygame.Rect(520, 215 + i * 90, 400, 10) for i in range(2)]
        self.back_rect = pygame.Rect(W // 2 - 120, 420, 240, 54)

    def back(self):
        self.game.settings.save()
        self.game.pop()

    def _set_from_mouse(self, i, mx):
        tr = self.tracks[i]
        self.game.settings[self.SLIDERS[i][1]] = (mx - tr.left) / tr.width
        self.game.audio.apply_volumes()

    def handle_event(self, e):
        g = self.game
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, tr in enumerate(self.tracks):
                if tr.inflate(30, 40).collidepoint(e.pos):
                    self.index, self.drag = i, i
                    self._set_from_mouse(i, e.pos[0])
            if self.back_rect.collidepoint(e.pos):
                g.audio.play("click")
                self.back()
        elif e.type == pygame.MOUSEMOTION:
            if self.drag is not None:
                self._set_from_mouse(self.drag, e.pos[0])
            elif self.back_rect.collidepoint(e.pos):
                self.index = 2
        elif e.type == pygame.MOUSEBUTTONUP and e.button == 1 and self.drag is not None:
            if self.drag == 1:
                g.audio.play("hit", 0.6)                    # 放開音效滑桿時播一聲試聽
            g.settings.save()
            self.drag = None
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.back()
            elif e.key in (pygame.K_UP, pygame.K_w):
                self.index = (self.index - 1) % 3
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self.index = (self.index + 1) % 3
            elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d) and self.index < 2:
                step = 0.05 if e.key in (pygame.K_RIGHT, pygame.K_d) else -0.05
                key = self.SLIDERS[self.index][1]
                g.settings[key] = g.settings[key] + step
                g.audio.apply_volumes()
                g.audio.play("select")
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE) and self.index == 2:
                g.audio.play("click")
                self.back()

    def draw(self, surf):
        dimmed_background(surf, self.game.assets)
        draw_panel(surf, pygame.Rect(300, 70, 680, 450))
        draw_text(surf, "設定", 46, CYAN, (W // 2, 120))
        for i, (label, key) in enumerate(self.SLIDERS):
            tr = self.tracks[i]
            sel = self.index == i
            val = self.game.settings[key]
            draw_text(surf, label, 28, WHITE if sel else GREY, (340, tr.centery), "midleft")
            pygame.draw.rect(surf, (40, 55, 90), tr, border_radius=5)
            pygame.draw.rect(surf, CYAN if sel else PURPLE,
                             (tr.left, tr.top, int(tr.width * val), tr.height), border_radius=5)
            pygame.draw.circle(surf, WHITE, (tr.left + int(tr.width * val), tr.centery), 14 if sel else 11)
            draw_text(surf, "%d%%" % round(val * 100), 24, WHITE, (tr.right + 25, tr.centery), "midleft")
        sel = self.index == 2
        box = pygame.Surface(self.back_rect.size, pygame.SRCALPHA)
        pygame.draw.rect(box, (18, 26, 52, 225), box.get_rect(), border_radius=12)
        pygame.draw.rect(box, (*(CYAN if sel else PURPLE), 255), box.get_rect(), 3, border_radius=12)
        surf.blit(box, self.back_rect.topleft)
        draw_text(surf, "返回", 28, WHITE if sel else GREY, self.back_rect.center)
        draw_text(surf, "← → 調整　↑ ↓ 切換　ESC 返回", 20, GREY, (W // 2, 490))


#  暫停選單
class PauseScene(Scene):
    def __init__(self, game):
        super().__init__(game)
        self.snapshot = game.screen.copy()               # 凍結當下畫面當背景
        items = [("繼續遊戲", self.resume), ("操作說明", lambda: game.push(HelpScene(game))),
                 ("設定", lambda: game.push(SettingsScene(game))), ("返回主選單", self.to_menu)]
        self.buttons = ButtonList(game, items, top=215)

    def resume(self):
        self.game.pop()

    def to_menu(self):
        self.game.replace(MainMenuScene(self.game))

    def handle_event(self, e):
        self.buttons.handle_event(e)
        if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p):
            self.resume()

    def draw(self, surf):
        surf.blit(self.snapshot, (0, 0))
        veil = pygame.Surface((W, H), pygame.SRCALPHA)
        veil.fill((4, 6, 18, 170))
        surf.blit(veil, (0, 0))
        draw_text(surf, "暫停", 56, CYAN, (W // 2, 150))
        self.buttons.draw(surf)


#  結束介面（只有 UI 外殼）
class GameOverScene(Scene):
    """結束介面：過關顯示「遊戲過關」，HP 歸零失敗才顯示「遊戲結束」。"""

    def __init__(self, game, score=0, leaderboard=None, victory=False, difficulty=1, remain_hp=0):
        super().__init__(game)
        self.score = score
        self.board = leaderboard or []
        self.victory = victory
        self.difficulty = difficulty
        self.remain_hp = remain_hp

        CN_NUM = {1: "一", 2: "二", 3: "三", 4: "四"}

        if not victory:
            # 情況 A：失敗（HP 歸零）→ 顯示「遊戲結束」，不可繼續下一關
            self.title = "遊戲結束"
            self.title_color = RED
            self.subtitle = None
            items = [
                ("重新開始", self.restart),
                ("回到主選單", self.to_menu),
            ]
        elif difficulty < 4:
            # 情況 B：難度 1 ~ 3 過關 → 顯示「遊戲過關」，可繼續下一關並延續生命
            next_diff = difficulty + 1
            self.title = "遊戲過關"
            self.title_color = CYAN
            self.subtitle = "第%s關完成！剩餘生命：%d（將延續至下一關）" % (CN_NUM[difficulty], remain_hp)
            items = [
                ("繼續第%s關" % CN_NUM[next_diff], self.next_stage),
                ("重新開始", self.restart),
                ("回到主選單", self.to_menu),
            ]
        else:
            # 情況 C：難度 4（最難關卡）過關 → 顯示「遊戲過關」與專屬通關文字
            self.title = "遊戲過關"
            self.title_color = CYAN
            self.subtitle = "你已完成最難關卡"
            items = [
                ("回到主選單", self.to_menu),
                ("結束遊戲", self.quit_game),
            ]

        self.buttons = ButtonList(game, items, top=465, w=320, h=48, gap=10, font=26)

    def next_stage(self):
        self.game.replace(GameplayScene(
            self.game,
            difficulty=self.difficulty + 1,
            initial_hp=self.remain_hp,
            initial_score=self.score,
        ))

    def restart(self):
        self.game.replace(GameplayScene(self.game, difficulty=self.difficulty))

    def to_menu(self):
        self.game.replace(MainMenuScene(self.game))

    def quit_game(self):
        self.game.running = False

    def handle_event(self, e):
        self.buttons.handle_event(e)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.to_menu()

    def draw(self, surf):
        dimmed_background(surf, self.game.assets, 175)
        draw_panel(surf, pygame.Rect(340, 35, 600, 415))
        draw_text(surf, self.title, 48, self.title_color, (W // 2, 82))

        if self.subtitle:
            draw_text(surf, self.subtitle, 22, PURPLE, (W // 2, 130))
            draw_text(surf, "目前分數  %d" % self.score, 32, WHITE, (W // 2, 168))
            board_y = 212
        else:
            draw_text(surf, "本次分數  %d" % self.score, 34, WHITE, (W // 2, 142))
            board_y = 195

        draw_text(surf, "排行榜", 24, CYAN, (W // 2, board_y))
        if not self.board:
            draw_text(surf, "（尚無紀錄）", 22, GREY, (W // 2, board_y + 55))
        for i, row in enumerate(self.board[:5]):
            name, val = row if isinstance(row, (tuple, list)) else ("", row)
            y = board_y + 34 + i * 30
            draw_text(surf, "%d." % (i + 1), 22, PURPLE, (470, y), "midleft")
            if name:
                draw_text(surf, str(name), 22, WHITE, (520, y), "midleft")
            draw_text(surf, str(val), 22, WHITE, (810, y), "midright")

        self.buttons.draw(surf)

#遊玩畫面
class GameplayScene(Scene):
    def __init__(self, game, difficulty=1, initial_hp=None, initial_score=0):
        super().__init__(game)
        self.assets = game.assets
        self.player = Player(self.assets.player_img)
        if initial_hp is not None:
            self.player.hp = max(1, min(self.player.max_hp, initial_hp))
        self.player_bullets, self.enemy_bullets = [], []
        self.enemies, self.particles, self.rings = [], [], []
        self.time = 0.0
        self.hurt_flash = 0.0
        self.bounds = PLAY.inflate(240, 240)
        self.stars = [[random.uniform(PLAY.left, PLAY.right), random.uniform(PLAY.top, PLAY.bottom),
                       random.choice((25, 50, 90)), random.choice((1, 1, 2))] for _ in range(70)]
        self.rules = GameRules(self, difficulty, initial_score=initial_score)
        self.rules.on_game_start()

    # 給 GameRules / 測試用的公開方法 
    def spawn_enemy(self, kind, y=None):
        """【接口】產生一架敵機（定時生怪的迴圈請在 GameRules.update() 裡呼叫這個）。"""
        if y is None:
            y = random.uniform(PLAY.top + 60, PLAY.bottom - 60)
        en = Enemy(kind, PLAY.right + 70, y, self.assets)
        self.enemies.append(en)
        return en

    def revive_player(self):
        self.player.reset()
        self.player.invuln = 2.0

    def enemy_shot(self, x, y, angle, speed, orb):
        img, r = self.assets.orbs[orb]
        self.enemy_bullets.append(Bullet(x, y, math.cos(angle) * speed, math.sin(angle) * speed, r, img))

    # 事件 
    def handle_event(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_ESCAPE, pygame.K_p):
                self.pause()
            elif DEBUG_KEYS:
                kinds = {pygame.K_F1: "aimed", pygame.K_F2: "fan", pygame.K_F3: "ring", pygame.K_F4: "spiral"}
                if e.key in kinds:
                    self.spawn_enemy(kinds[e.key])
        elif e.type == getattr(pygame, "WINDOWFOCUSLOST", -1):   # 視窗失焦自動暫停
            self.pause()

    def pause(self):
        self.game.push(PauseScene(self.game))

    # 特效 
    def explode(self, x, y, big=False):
        n = 46 if big else 24
        for _ in range(n):
            a = random.uniform(0, math.tau)
            sp = random.uniform(40, 340 if big else 240)
            col = random.choice(((255, 240, 180), (255, 170, 60), (255, 90, 40), (255, 255, 255)))
            life = random.uniform(0.35, 0.8)
            self.particles.append(Particle(x, y, math.cos(a) * sp, math.sin(a) * sp, life, col,
                                           random.uniform(2.5, 6 if big else 5)))
        self.rings.append([x, y, 0.0, 95 if big else 55])

    def spark(self, x, y):
        for _ in range(3):
            a = random.uniform(0, math.tau)
            sp = random.uniform(60, 160)
            self.particles.append(Particle(x, y, math.cos(a) * sp, math.sin(a) * sp, 0.2, (180, 240, 255), 2.5))

    # 傷害
    def damage_player(self, dmg=1):
        p = self.player
        if not p.alive or p.invuln > 0:
            return
        p.hp = max(0, p.hp - dmg)
        p.invuln = PLAYER_INVULN_TIME
        self.hurt_flash = 0.25
        self.game.audio.play("hit")
        self.rules.on_player_hit(dmg)                    # 【接口】
        if p.hp <= 0:
            p.alive = False
            self.explode(p.x, p.y, big=True)
            self.game.audio.play("explode")
            self.enemy_bullets.clear()
            self.rules.on_player_dead()                  # 【接口】勝負判定 / 遊戲結束

    def kill_enemy(self, en):
        en.dead = True
        self.explode(en.x, en.y, big=en.hit_r > 40)
        self.game.audio.play("explode", 0.8)
        self.rules.on_enemy_killed(en)                   # 【接口】分數計算

    def update(self, dt):
        self.time += dt
        self.hurt_flash = max(0.0, self.hurt_flash - dt)
        self.rules.update(dt)                            # 定時生怪迴圈 / 難度
        keys = pygame.key.get_pressed()
        p = self.player

        if p.alive:
            p.update(dt, keys)
            if (keys[pygame.K_z] or keys[pygame.K_j] or keys[pygame.K_SPACE]) and p.fire_cd <= 0:
                p.fire_cd = PLAYER_FIRE_INTERVAL
                for oy in (-14, 14):
                    self.player_bullets.append(Bullet(p.x + 40, p.y + oy, 950, 0, 6, self.assets.bolt))
                self.game.audio.play("shoot", 0.35)

        for s in self.stars:                              # 星點捲動（視差）
            s[0] -= s[2] * dt
            if s[0] < PLAY.left:
                s[0], s[1] = PLAY.right, random.uniform(PLAY.top, PLAY.bottom)

        for b in self.player_bullets:
            b.update(dt, self.bounds)
        for b in self.enemy_bullets:
            b.update(dt, self.bounds)
        for en in self.enemies:
            en.update(dt, self)

        # 玩家子彈 敵機
        for b in self.player_bullets:
            for en in self.enemies:
                if en.dead or b.dead:
                    continue
                if (b.x - en.x) ** 2 + (b.y - en.y) ** 2 <= (b.r + en.hit_r) ** 2:
                    b.dead = True
                    en.hurt(b.dmg)
                    self.spark(b.x, b.y)
                    if en.hp <= 0:
                        self.kill_enemy(en)

        # 敵方子彈 / 敵機機身 玩家
        if p.alive and p.invuln <= 0:
            for b in self.enemy_bullets:
                if (b.x - p.x) ** 2 + (b.y - p.y) ** 2 <= (b.r + p.hit_r) ** 2:
                    b.dead = True
                    self.damage_player(1)
                    break
        if p.alive and p.invuln <= 0:
            for en in self.enemies:
                if (en.x - p.x) ** 2 + (en.y - p.y) ** 2 <= (en.hit_r * 0.8 + p.hit_r) ** 2:
                    self.damage_player(1)
                    break

        # 粒子 / 衝擊環
        for q in self.particles:
            q.life -= dt
            q.x += q.vx * dt
            q.y += q.vy * dt
            q.vx *= 0.96
            q.vy *= 0.96
        for r in self.rings:
            r[2] += dt

        # 清理
        self.player_bullets = [b for b in self.player_bullets if not b.dead]
        self.enemy_bullets = [b for b in self.enemy_bullets if not b.dead]
        self.enemies = [en for en in self.enemies if not en.dead]
        self.particles = [q for q in self.particles if q.life > 0]
        self.rings = [r for r in self.rings if r[2] < 0.35]
 
    def draw(self, surf):
        surf.blit(self.assets.game_bg, (0, 0))
        surf.set_clip(PLAY)                               # 以下物件只在艙窗內顯示
        for x, y, _, size in self.stars:
            surf.fill((200, 220, 255), (int(x), int(y), size, size))
        for en in self.enemies:
            en.draw(surf)
        if self.player.alive:
            self.player.draw(surf, self.time)
        for b in self.player_bullets:
            b.draw(surf)
        for b in self.enemy_bullets:                      # 敵彈畫在最上層，確保看得清楚
            b.draw(surf)
        for q in self.particles:
            rad = max(1, int(q.size * q.life / q.max_life))
            pygame.draw.circle(surf, q.color, (int(q.x), int(q.y)), rad)
        for x, y, age, max_r in self.rings:
            k = age / 0.35
            pygame.draw.circle(surf, (255, 220, 160), (int(x), int(y)), int(max_r * k), max(1, int(4 * (1 - k))))
        surf.set_clip(None)

        if self.hurt_flash > 0:                           # 受傷紅閃
            veil = pygame.Surface((W, H), pygame.SRCALPHA)
            veil.fill((255, 30, 30, int(110 * self.hurt_flash / 0.25)))
            surf.blit(veil, (0, 0))
        self.draw_hud(surf)

    def draw_hud(self, surf):
        #HUD 放在艙窗下方的空白處：血量、分數、難度與目前關卡進度
        p = self.player
        x0, y0 = PLAY.left + 5, PLAY.bottom + 14
        draw_text(surf, "HP", 24, CYAN, (x0, y0 + 12), "midleft")
        for i in range(p.max_hp):
            r = pygame.Rect(x0 + 48 + i * 34, y0, 28, 24)
            full = i < p.hp
            pygame.draw.rect(surf, (60, 200, 255) if full else (30, 40, 70), r, border_radius=5)
            pygame.draw.rect(surf, WHITE if full else (70, 85, 120), r, 2, border_radius=5)

        # 下排左側：分數
        draw_text(surf, "分數  %d" % self.rules.score, 28, WHITE, (x0, y0 + 50), "midleft")

        # 右側：目前難度與第 X / 4 關
        diff_text = "難度 %d" % self.rules.difficulty
        stage_text = "第 %d / %d 關" % (self.rules.current_stage, self.rules.total_stages)
        draw_text(surf, diff_text, 24, PURPLE, (x0 + 280, y0 + 12), "midleft")
        draw_text(surf, stage_text, 24, CYAN, (x0 + 280, y0 + 50), "midleft")

        if DEBUG_KEYS:
            draw_text(surf, "F1~F4 生怪(測試)", 16, GREY, (x0 + 450, y0 + 12), "midleft", shadow=False)

#遊戲主體
class Game:
    def __init__(self):
        pygame.mixer.pre_init(22050, -16, 1, 512)
        pygame.init()
        flags = pygame.SCALED | pygame.RESIZABLE
        try:
            self.screen = pygame.display.set_mode((W, H), flags, vsync=1)
        except pygame.error:
            self.screen = pygame.display.set_mode((W, H), flags)
        pygame.display.set_caption(TITLE)
        self.data_dir = user_data_dir()
        self.settings = Settings(self.data_dir)
        self.assets = Assets()
        self.audio = Audio(self.settings)
        try:
            pygame.display.set_icon(pygame.transform.smoothscale(self.assets.player_img, (48, 36)))
        except pygame.error:
            pass
        self.stack = []
        self.running = True
        self.fade = 0.0
        self.replace(MainMenuScene(self))
        self.audio.play_music()

    # --- 場景堆疊：push = 疊上去(返回時回到下層)、pop = 返回、replace = 清空後換成新場景
    def push(self, scene):
        self.stack.append(scene)
        self.fade = 1.0

    def pop(self):
        if len(self.stack) > 1:
            self.stack.pop()
            self.fade = 1.0

    def replace(self, scene):
        self.stack = [scene]
        self.fade = 1.0

    def show_game_over(self, score, leaderboard=None, victory=False, difficulty=1, remain_hp=0):
        self.replace(GameOverScene(self, score, leaderboard, victory, difficulty, remain_hp))

    async def run(self):
        clock = pygame.time.Clock()
        veil = pygame.Surface((W, H))
        while self.running and self.stack:
            raw_dt = clock.tick(0 if sys.platform == "emscripten" else FPS) / 1000.0
            dt = min(raw_dt, 0.05)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.running = False
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_F11:
                    pygame.display.toggle_fullscreen()
                elif self.stack:
                    self.stack[-1].handle_event(e)
            if not self.stack:
                break
            scene = self.stack[-1]
            scene.update(dt)
            scene.draw(self.screen)
            if self.fade > 0:
                self.fade = max(0.0, self.fade - dt * 4)
                veil.set_alpha(int(255 * self.fade))
                self.screen.blit(veil, (0, 0))
            pygame.display.flip()
            await asyncio.sleep(0)          # 關鍵！這行沒寫進存檔就會「網頁無回應」
        self.settings.save()
        pygame.quit()

async def main():
    await Game().run()

if __name__ == "__main__":
    asyncio.run(main())
