# 彈幕遊戲 (Pygame)

## 在別台電腦執行
1. 安裝 Python 3.9 以上（Windows 安裝時勾選 "Add Python to PATH"）。
2. 把整個 `bullet_hell_game` 資料夾複製過去（務必連同 `assets/`）。
3. Windows 雙擊 `run_windows.bat`；Mac/Linux 執行 `./run_mac_linux.sh`。
   或手動：`pip install -r requirements.txt` → `python main.py`

## 打包成 exe（對方不用裝 Python）
Windows 雙擊 `build_exe.bat`，成品在 `dist/BulletHell.exe`。
（Mac/Linux：`pyinstaller --noconsole --onefile --add-data "assets:assets" main.py`）

## 操作
移動 WASD/方向鍵｜射擊 Z/J/空白｜Shift 精準移動｜ESC/P 暫停｜F11 全螢幕
測試：遊戲中 F1~F4 手動生出四種敵機（main.py 的 `DEBUG_KEYS`）。

## 接入規則邏輯（你要補的部分）
全部集中在 `game_rules.py` 的 `GameRules`，每個接口都有註解與範例：
| 接口 | 用途 |
|---|---|
| `update(dt)` | 定時產生敵機的迴圈 |
| `on_enemy_killed(enemy)` | 分數計算（HUD 讀 `self.score`） |
| `on_player_dead()` | 勝負判定／遊戲結束（目前 demo 是直接復活，記得刪） |
| `finish_game()` | 記分板更新、儲存本地排行榜、切到結束介面 |
main.py 內搜尋「【接口】」可看到所有呼叫點。

## 素材
`assets/images`：menu.jpg、background.jpg、player.png、enemy.png（可同檔名替換）
`assets/audio`：目前是程式產生的暫代音效/BGM，同檔名換成自己的 .wav 即可（`tools/make_placeholder_audio.py` 可重新產生）
`assets/fonts`：內附 Noto Sans TC（OFL 授權），換電腦不會出現方塊字。
設定檔存於 `save_data/settings.json`（打包成 exe 後在使用者目錄 `~/.bullet_hell_game/`）。
