import json
import os
import random

ENEMY_TYPES = {
    1: "aimed",   # 難度 1：自機狙
    2: "fan",     # 難度 2：扇形
    3: "ring",    # 難度 3：環形
    4: "spiral",  # 難度 4：螺旋
}

# 各難度的 4 波出怪表：(等待秒數, [(敵機難度編號, 數量), ...]) 
WAVE_CONFIGS = {
    1: [
        (1.0, [(1, 2)]),          # 第 1 波（進場 1 秒）：2 台難度 1
        (6.0, [(1, 3)]),          # 第 2 波（隔 6 秒）：3 台難度 1
        (6.0, [(1, 4)]),          # 第 3 波（隔 6 秒）：4 台難度 1
        (6.0, [(2, 1)]),          # 第 4 波（隔 6 秒）：1 台難度 2（共 10 台）
    ],
    2: [
        (1.0, [(2, 2)]),
        (6.0, [(2, 3)]),
        (6.0, [(2, 4)]),
        (6.0, [(3, 1)]),          # 第 4 波：1 台難度 3（共 10 台）
    ],
    3: [
        (1.0, [(3, 2)]),
        (6.0, [(3, 3)]),
        (6.0, [(3, 4)]),
        (6.0, [(4, 1)]),          # 第 4 波：1 台難度 4（共 10 台）
    ],
    4: [
        (1.0, [(4, 2)]),                         # 第 1 波：2 台難度 4
        (6.0, [(1, 2), (2, 1)]),                 # 第 2 波：難度 1×2 + 難度 2×1（3 台）
        (6.0, [(1, 2), (3, 2)]),                 # 第 3 波：難度 1×2 + 難度 3×2（4 台）
        (6.0, [(1, 1), (2, 1), (3, 1), (4, 1)]), # 第 4 波：難度 1~4 各 1 台（共 13 台）
    ],
}


class GameRules:
    def __init__(self, scene, difficulty=1, initial_score=0):
        self.scene = scene
        self.difficulty = difficulty          # 目前大關卡 / 難度（1 ~ 4）
        self.score = initial_score            # 延續上一難度的累積分數（若重新開始則為 0）
        self.elapsed = 0.0
        self.wave_index = 0
        self.wave_timer = 0.0
        self.finished = False                 # 防止結算畫面被重複觸發
        self.waves = WAVE_CONFIGS.get(difficulty, WAVE_CONFIGS[1])

    @property
    def current_stage(self):
        return max(1, min(len(self.waves), self.wave_index))
    
    @property
    def total_stages(self):
        return len(self.waves)

    def on_game_start(self):
        self.elapsed = 0.0
        self.wave_index = 0
        self.wave_timer = 0.0
        self.finished = False

    def update(self, dt):
        if self.finished:
            return
        self.elapsed += dt

        # 1. 依序執行第 1 ~ 4 波出怪
        if self.wave_index < len(self.waves):
            self.wave_timer += dt
            wait_sec, spawn_list = self.waves[self.wave_index]

            if self.wave_timer >= wait_sec:
                self.wave_timer -= wait_sec
                self._spawn_wave(spawn_list)
                self.wave_index += 1

        # 2.四波都已出完，場上敵機全部清空，且玩家還活著 → 過關勝利
        elif len(self.scene.enemies) == 0 and self.scene.player.alive:
            self.finish_game(victory=True)

    def _spawn_wave(self, spawn_list):
        queue = []
        for diff_lv, count in spawn_list:
            kind = ENEMY_TYPES[diff_lv]
            queue.extend([kind] * count)

        total = len(queue)
        top_y, bottom_y = 110, 420
        for i, kind in enumerate(queue):
            if total == 1:
                y = random.uniform(top_y + 40, bottom_y - 40)
            else:
                step = (bottom_y - top_y) / (total - 1)
                y = top_y + i * step + random.uniform(-15, 15)
            self.scene.spawn_enemy(kind, y=y)

    def on_enemy_killed(self, enemy):
        self.score += enemy.score_value

    def on_player_hit(self, damage):
        pass

    def on_player_dead(self):
        # 玩家生命歸零 → 戰敗結算
        self.finish_game(victory=False)

    def finish_game(self, victory=False):
        if self.finished:
            return
        self.finished = True

        # 讀取與更新本地排行榜
        path = os.path.join(self.scene.game.data_dir, "leaderboard.json")
        try:
            with open(path, "r", encoding="utf-8") as f:
                board = json.load(f)
        except (OSError, ValueError):
            board = []

        board.append(self.score)
        board = sorted(board, reverse=True)[:10]

        with open(path, "w", encoding="utf-8") as f:
            json.dump(board, f, indent=2)

        # 傳入「是否過關」、「目前難度」、「玩家剩餘血量」給結束畫面
        remain_hp = self.scene.player.hp if victory else 0
        self.scene.game.show_game_over(
            self.score,
            board,
            victory=victory,
            difficulty=self.difficulty,
            remain_hp=remain_hp,
        )