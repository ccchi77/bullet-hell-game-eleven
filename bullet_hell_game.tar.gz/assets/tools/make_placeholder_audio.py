# -*- coding: utf-8 -*-
"""
產生「暫代用」的音效與背景音樂 (assets/audio/*.wav)。
需要 numpy：  pip install numpy
執行：        python tools/make_placeholder_audio.py
之後你可以直接用自己的 wav 檔「同檔名覆蓋」assets/audio 裡的檔案，遊戲不用改程式。
"""
import os
import wave
import numpy as np

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
os.makedirs(OUT, exist_ok=True)


def save(name, data):
    data = np.clip(data, -1, 1)
    pcm = (data * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def sweep(f0, f1, dur, wave_type="sine", decay=6.0):
    t = np.linspace(0, dur, int(SR * dur), endpoint=False)
    f = np.linspace(f0, f1, t.size)
    ph = 2 * np.pi * np.cumsum(f) / SR
    if wave_type == "square":
        s = np.sign(np.sin(ph)) * 0.6
    elif wave_type == "saw":
        s = 2 * ((ph / (2 * np.pi)) % 1) - 1
    else:
        s = np.sin(ph)
    return s * np.exp(-decay * t / dur)


def noise(dur, decay=5.0):
    t = np.linspace(0, dur, int(SR * dur), endpoint=False)
    rng = np.random.default_rng(1)
    return rng.uniform(-1, 1, t.size) * np.exp(-decay * t / dur)


save("shoot.wav", sweep(1100, 500, 0.08, "square", 5) * 0.5)
save("explode.wav", noise(0.35, 6) * 0.8 + sweep(160, 40, 0.35, "saw", 6) * 0.4)
save("hit.wav", sweep(300, 60, 0.30, "saw", 5) * 0.7 + noise(0.30, 8) * 0.3)
save("click.wav", sweep(700, 1200, 0.09, "sine", 5) * 0.7)
save("select.wav", sweep(900, 900, 0.04, "sine", 4) * 0.6)

# ---- 背景音樂：Am - F - C - G，16 秒可循環 ----
bpm = 120
beat = 60 / bpm
chords = [(220.00, 261.63, 329.63), (174.61, 220.00, 261.63),
          (261.63, 329.63, 392.00), (196.00, 246.94, 293.66)]
bass = [110.00, 87.31, 130.81, 98.00]
song = []
for rep in range(2):
    for ci, ch in enumerate(chords):
        seg = np.zeros(int(SR * beat * 4))
        for step in range(8):                      # 8 分音符琶音
            f = ch[step % 3] * (2 if step % 2 else 1)
            n = int(SR * beat / 2)
            t = np.arange(n) / SR
            note = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)) * np.exp(-4 * t / (beat / 2))
            a = step * n
            seg[a:a + n] += note * 0.22
        t = np.arange(seg.size) / SR
        seg += np.sin(2 * np.pi * bass[ci] * t) * 0.25 * (0.6 + 0.4 * np.sin(2 * np.pi * t / beat))
        song.append(seg)
song = np.concatenate(song)
fade = 400
song[:fade] *= np.linspace(0, 1, fade); song[-fade:] *= np.linspace(1, 0, fade)
save("bgm.wav", song * 0.8)
print("done ->", os.path.abspath(OUT))
